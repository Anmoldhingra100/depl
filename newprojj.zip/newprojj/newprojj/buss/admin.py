from django.contrib import admin
from .models import up_ticket

@admin.register(up_ticket)
class UpTicketAdmin(admin.ModelAdmin):
    list_display = ('ticket_id', 'type_of_bus', 'phone_number', 'source', 'destination', 'number_of_tickets', 'date', 'time')
    search_fields = ('ticket_id', 'source', 'destination', 'phone_number')
    list_filter = ('type_of_bus', 'date')
    ordering = ('date', 'time')



from django.contrib import admin
from .models import Complaint

@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ('firstname', 'lastname', 'location', 'phone', 'victim_name')
    search_fields = ('firstname', 'lastname', 'location', 'victim_name')
    list_filter = ('location',)


from django.contrib import admin
from .models import BusPass

@admin.register(BusPass)
class BusPassAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'college', 'start_date', 'end_date', 'source', 'destination')
    search_fields = ('first_name', 'last_name', 'college', 'source', 'destination')
    list_filter = ('start_date', 'end_date', 'college')

    # Optional: to add additional configurations
    ordering = ('start_date',)



