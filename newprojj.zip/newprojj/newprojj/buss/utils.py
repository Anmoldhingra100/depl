# utils.py
def get_geocode(address):
    # Function implementation
    pass
