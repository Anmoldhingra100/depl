import json
from django.core.wsgi import get_wsgi_application

# Initialize Django application
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "newprojj.settings")
application = get_wsgi_application()

def handler(event, context):
    # Handle the incoming request here
    response = application(event, context)
    return {
        'statusCode': response.status_code,
        'body': json.dumps(response.content.decode('utf-8'))
    }
